from django.db import models
from django.contrib.auth.models import AbstractUser

# Create your models here.

class CustomUser(AbstractUser):
    USER = (
        ('1','Director'),
        ('2','Staff'),
        )

    user_type = models.CharField(choices=USER,max_length=50,default='1')

class faculty(models.Model):
    
     admin = models.OneToOneField(CustomUser,on_delete=models.CASCADE)
     address = models.TextField(default=True)
     gender = models.CharField(max_length=100)
     departmnet = models.CharField(max_length=100)
     designation = models.CharField(max_length=100)
     sick_leave = models.IntegerField()
     casual_leave = models.IntegerField()
     duty_leave = models.IntegerField()
     leave_without_pay = models.IntegerField()
     created_at = models.DateTimeField(auto_now_add=True, null=True)
     updated_at = models.DateTimeField(auto_now=True,null=True)

     def __str__(self):
        return self.admin.first_name + " " + self.admin.last_name
    
class leaves(models.Model):
     c = (
        ('sick leave','sick leave'),
        ('duty leave','duty leave'),
        ('casual leave','casual leave'),
        ('leave without pay','leave without pay'),
        )
     faculty_id= models.ForeignKey(faculty,on_delete=models.CASCADE)   
     data=models.CharField(max_length=100)
     reason=models.TextField()
     leave_type=models.CharField(choices = c,max_length=100)
     status = models.IntegerField(default=0)
     created_at=models.DateTimeField(auto_now_add=True)
     updated_at=models.DateTimeField(auto_now_add=True)