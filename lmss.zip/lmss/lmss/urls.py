"""lmss URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from . import views, staff_views, director_views
urlpatterns = [
    
    path('admin/', admin.site.urls),
    path('base/', views.BASE, name='base'),
    path('', views.index, name='index'),
    path('login', views.login, name='login'),
    
    path('flogin', views.flogin, name='flogin'),
    
    path('dologin', views.dologin, name='dologin'),
    
    path('doflogin', views.doflogin, name='doflogin'),
    
    path('director/home', director_views.home, name='dhome'),
    
    path('dologout', views.dologout, name='dologout'),
    
    path('proo', views.proo, name='proo'),
    
    path('staff/holiday', staff_views.holiday, name='holiday'),
    
    path('director/holiday', director_views.holiday, name='dholiday'),
    
    path('Profile/update',views.PROFILE_UPDATE,name='profile_update'),
    
    path('director/Staff/Add',director_views.add_staff,name='add_staff'),
    
    path('director/Staff/Views', director_views.view_staff, name= 'view_staff'),
    
    path('staff/home',staff_views.home, name='home'),
    
    path('staff/apply_leave', staff_views.apply_leave, name= 'apply_leave'),
    
    path('staff/leave_history', staff_views.leave_history, name= 'leave_history'),
    
    path('staff/leave_save', staff_views.leave_save, name= 'leave_save'),
    
    
    path('director/approve_leave/<str:id>', director_views.approve_leave, name= 'approve_leave'),
    
    path('director/disapprove_leave/<str:id>', director_views.disapprove_leave, name= 'disapprove_leave'),
    
    
]+ static(settings.MEDIA_URL,document_root= settings.MEDIA_ROOT)
