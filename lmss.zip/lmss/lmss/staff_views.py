from app.models import leaves, faculty
from django.template import loader
from django.shortcuts import render, redirect, HttpResponse
def home(request):
    
 
    return render(request, 'staff/home.html')

def apply_leave(request):
  
    return render(request, 'staff/apply_leave.html',)

def leave_history(request):
   
        
    staff = faculty.objects.filter(admin = request.user.id)
       
    for i in staff:
          
        staff_id = i.id
        staff_leave_history = leaves.objects.filter( faculty_id = staff_id)
        
        dc = {
            'staff_leave_history' : staff_leave_history,  
        }
        return render(request, 'staff/leave_history.html', dc)

def leave_save(request):
    if request.method == 'POST':
        leave_date=request.POST.get('leave_date')
        reason=request.POST.get('reason')
        leave_type=request.POST.get('leave_type')
        
        try:
            staff= faculty.objects.get(admin= request.user.id)
            leave= leaves(
                
             faculty_id = staff,
             data = leave_date,
             reason=reason,
             leave_type=leave_type, 
            
         
        )
            leave.save('apply_leave')
        
        except:
            print(str(request.user.id), "hii")
    return render(request, 'staff/home.html')


def holiday(request):
    return render (request , 'staff/holiday.html')

