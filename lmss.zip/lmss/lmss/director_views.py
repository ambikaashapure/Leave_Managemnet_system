from django.shortcuts import render, redirect, HttpResponse
from django.contrib.auth.decorators import login_required
from app.models import CustomUser,faculty,leaves
from django. contrib import messages
from django.template import loader

def home(request):
    leave = leaves.objects.all()
    context = {
        'leaves' : leave,
    }
    return render(request, 'director/home.html', context)

def approve_leave(request, id):
    leave = leaves.objects.get(id = id)
    leave.status = 1
    leave.save()
    return redirect("dhome")
    return None

def disapprove_leave(request, id):
    leave = leaves.objects.get(id = id)
    leave.status = 2
    leave.save()
    return redirect("dhome")
    return None

@login_required()
def add_staff(request):
     if request.method == "POST":
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        email = request.POST.get('email')
        username = request.POST.get('username')
        password = request.POST.get('password')
        address = request.POST.get('address')
        gender = request.POST.get('gender')
        department = request.POST.get('department')
        designation = request.POST.get('designation')
        sick_leave = request.POST.get('sl')
        casual_leave = request.POST.get('cl')
        duty_leave = request.POST.get('dl')
        leave_without_pay = request.POST.get('lwp')
        
        
        if CustomUser.objects.filter(email=email).exists():
           messages.warning(request,'Email Is Already Taken')
           return redirect('add_staff')
       
        if CustomUser.objects.filter(username=username).exists():
          messages.warning(request,'Username Is Already Taken')
          return redirect('add_staff')
        else:
            user = CustomUser(
                first_name = first_name,
                last_name = last_name,
                username = username,
                email = email,
            )
            user.set_password(password)
            user.save()
            

            
        Faculty = faculty(
                admin = user,
                address = address,
                gender = gender,
                department=department,
                designation=designation,
                sick_leave=sick_leave,
                duty_leave=duty_leave,
                casual_leave=casual_leave,
                leave_without_pay=leave_without_pay,
        )
        Faculty.save()
        messages.success(request, " Are Successfully Added !")
        return render('director/home.html')


    

     return render(request,'director/add_staff.html')
     return render(request,'director/add_staff.html')


def view_staff(request):
    
    
    Faculty= faculty.objects.all()
    template = loader.get_template('director/view_staff.html')
    context = { 'fdata' : Faculty ,  }
    print(Faculty)
    return HttpResponse(template.render(context, request))
 
    return render(request, 'faculty/index.html')
    
    return render (request, 'director/view_staff.html')

def holiday(request):
    return render (request , 'director/holiday.html')